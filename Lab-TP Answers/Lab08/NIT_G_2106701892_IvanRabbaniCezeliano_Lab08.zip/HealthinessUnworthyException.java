public class HealthinessUnworthyException extends Exception {
    
    // Menyimpan message dari error buatan
    public HealthinessUnworthyException() {
        super("TIDAK LAYAK");
    }
}
